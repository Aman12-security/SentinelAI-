# 🤝 Contributing to SentinelAI

Thank you for your interest in contributing!

---

## 🐛 Reporting Bugs

Open an issue with:
- **Steps to reproduce** (exact command + log sample if possible)
- **Expected vs actual behavior**
- **Environment:** OS, Python version, `pip list` output

---

## 💡 Suggesting Features

Open an issue tagged `[Feature Request]`. Some ideas already on the roadmap:
- Real-time log tailing
- Additional log format support (Windows Event Log, cloud audit logs)
- Slack/email alerting
- GeoIP enrichment

---

## 🔧 Making Code Changes

```bash
git clone https://github.com/YOUR_USERNAME/SentinelAI.git
cd SentinelAI
git checkout -b feature/your-feature-name

# Make changes

python -m pytest tests/ -v   # All 31+ tests must pass

git commit -m "✨ Add: description of your change"
git push origin feature/your-feature-name
# Open a Pull Request on GitHub
```

---

## 📋 Commit Message Format

```
✨ Add:      New feature
🐛 Fix:      Bug fix
📝 Docs:     Documentation
♻️  Refactor: Code cleanup (no behavior change)
✅ Test:     Adding or fixing tests
🔐 Security: Security improvement
```

---

## 📜 Code Style

- Follow PEP 8
- Docstrings on all public functions/classes
- Type hints on function signatures where practical
- New detection logic should include corresponding unit tests with synthetic log examples

---

## 👥 Code of Conduct

Be respectful, be constructive, focus on the code. By contributing, you agree your code will be licensed under the MIT License.
