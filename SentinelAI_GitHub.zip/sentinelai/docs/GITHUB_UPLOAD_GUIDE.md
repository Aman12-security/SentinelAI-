# 📤 GITHUB_UPLOAD_GUIDE.md — SentinelAI

Step-by-step guide to push SentinelAI to GitHub for your portfolio.

---

## 🧰 Prerequisites

Install Git if not already installed:
- **Windows:** https://git-scm.com/download/win
- **Linux:** `sudo apt install git`
- **macOS:** `brew install git`

Verify: `git --version`

---

## Step 1 — Create GitHub Repository

1. Go to **https://github.com/new**
2. Fill in:
   - **Repository name:** `SentinelAI`
   - **Description:** `🛡️ AI-powered Linux auth log threat detector — Isolation Forest ML detection + Claude LLM narration`
   - **Visibility:** ✅ Public (for portfolio)
   - **Initialize:** ❌ Do NOT check "Add README" (we have our own)
3. Click **Create repository**
4. Copy the repo URL shown (e.g. `https://github.com/yourusername/SentinelAI.git`)

---

## Step 2 — Initialize Git Locally

```bash
cd SentinelAI
git init
git add .
git status   # ← Verify .env is NOT listed!
```

**You should NOT see:**
- `.env`
- `__pycache__/`
- `.pytest_cache/`
- any real production `.log` files

---

## Step 3 — First Commit

```bash
git commit -m "🛡️ Initial commit: SentinelAI - AI-Powered Auth Log Threat Detector

- Isolation Forest unsupervised anomaly detection
- Claude LLM narration with offline template fallback
- Regex-based syslog parser for SSH/sudo/PAM events
- Behavioral feature engineering (11 features, time-windowed)
- 31 unit + integration tests
- Sample log with embedded brute-force/enumeration/privilege-escalation patterns"
```

---

## Step 4 — Connect to GitHub & Push

```bash
git remote add origin https://github.com/YOUR_USERNAME/SentinelAI.git
git branch -M main
git push -u origin main
```

> ⚠️ If GitHub asks for a password, use a **Personal Access Token** (PAT):
> GitHub → Settings → Developer Settings → Personal Access Tokens → Generate New Token

---

## Step 5 — Repository Settings

After pushing, go to **Settings** (or the About gear icon) and add:

**Description:**
```
🛡️ AI-powered Linux auth log threat detector — Isolation Forest ML detection + Claude LLM narration, delivered as a GitHub-ready Python CLI tool
```

**Topics:**
```
python  machine-learning  cybersecurity  anomaly-detection
isolation-forest  llm  claude-ai  threat-detection
log-analysis  cli-tool  siem  portfolio
```

---

## 🌟 Add a CI Badge (Optional but impressive)

Create `.github/workflows/tests.yml`:
```yaml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install -r requirements.txt
      - run: python -m pytest tests/ -v
```

Then add this to the top of your README:
```markdown
![Tests](https://github.com/YOUR_USERNAME/SentinelAI/actions/workflows/tests.yml/badge.svg)
```

---

## 📋 Final Checklist Before Making Public

- [ ] `.env` is in `.gitignore` and NOT uploaded
- [ ] No real production auth.log files committed
- [ ] README renders correctly on GitHub (check preview)
- [ ] All 5 source files are in `src/`
- [ ] `requirements.txt` is present
- [ ] `LICENSE` is present (MIT)
- [ ] Topics/tags added
- [ ] Sample log + tests included for instant credibility

---

## 🚀 Add to Your Resume/Portfolio

```
SentinelAI — AI-Powered Linux Auth Log Threat Detector
GitHub: github.com/YOUR_USERNAME/SentinelAI
Tech: Python, scikit-learn (Isolation Forest), Claude API, pandas

• Built an unsupervised ML pipeline (Isolation Forest) to detect brute-force,
  credential-stuffing, account-enumeration, and privilege-escalation patterns
  in Linux auth logs without requiring labeled attack data
• Integrated Claude LLM to translate ML risk scores into plain-English SOC
  analyst reports with attack-pattern classification and recommended actions
• Designed a fully offline-capable fallback narration engine, ensuring the
  tool functions without any external API dependency
• Achieved 100% test coverage across 31 unit and integration tests
```
