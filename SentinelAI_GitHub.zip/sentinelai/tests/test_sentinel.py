"""
SentinelAI Unit Tests
Run with: python -m pytest tests/ -v
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from datetime import datetime
import pandas as pd

from log_parser import AuthLogParser, AuthEvent
from feature_builder import FeatureBuilder
from anomaly_detector import AnomalyDetector
from llm_narrator import LLMNarrator


# ─── Log Parser Tests ──────────────────────────────────────

class TestAuthLogParser:
    def setup_method(self):
        self.parser = AuthLogParser(default_year=2026)

    def test_failed_password(self):
        line = "Jun 13 09:14:02 prod-web01 sshd[14213]: Failed password for root from 203.0.113.55 port 51422 ssh2"
        evt = self.parser.parse_line(line)
        assert evt is not None
        assert evt.event_type == 'failed_login'
        assert evt.user == 'root'
        assert evt.source_ip == '203.0.113.55'
        assert evt.port == 51422

    def test_failed_password_invalid_user(self):
        line = "Jun 13 09:14:07 prod-web01 sshd[14217]: Failed password for invalid user admin from 203.0.113.55 port 51425 ssh2"
        evt = self.parser.parse_line(line)
        assert evt.event_type == 'failed_login'
        assert evt.user == 'admin'

    def test_accepted_password(self):
        line = "Jun 13 09:30:00 prod-web01 sshd[15011]: Accepted password for deploy from 10.0.0.12 port 22150 ssh2"
        evt = self.parser.parse_line(line)
        assert evt.event_type == 'accepted_login'
        assert evt.user == 'deploy'
        assert evt.auth_method == 'password'

    def test_accepted_publickey(self):
        line = "Jun 13 02:14:01 prod-web01 sshd[10231]: Accepted publickey for deploy from 10.0.0.12 port 51022 ssh2"
        evt = self.parser.parse_line(line)
        assert evt.event_type == 'accepted_login'
        assert evt.auth_method == 'publickey'

    def test_invalid_user(self):
        line = "Jun 13 09:14:06 prod-web01 sshd[14216]: Invalid user admin from 203.0.113.55"
        evt = self.parser.parse_line(line)
        assert evt.event_type == 'invalid_user'
        assert evt.user == 'admin'
        assert evt.source_ip == '203.0.113.55'

    def test_sudo_command(self):
        line = "Jun 13 11:05:14 prod-web01 sudo: amanX : TTY=pts/0 ; PWD=/home/amanX ; USER=root ; COMMAND=/bin/systemctl restart nginx"
        evt = self.parser.parse_line(line)
        assert evt.event_type == 'sudo_command'
        assert evt.user == 'amanX'
        assert evt.target_user == 'root'
        assert 'systemctl' in evt.command

    def test_session_opened(self):
        line = "Jun 13 02:14:01 prod-web01 sshd[10231]: pam_unix(sshd:session): session opened for user deploy"
        evt = self.parser.parse_line(line)
        assert evt.event_type == 'session_open'
        assert evt.user == 'deploy'

    def test_session_closed(self):
        line = "Jun 13 02:18:44 prod-web01 sshd[10231]: pam_unix(sshd:session): session closed for user deploy"
        evt = self.parser.parse_line(line)
        assert evt.event_type == 'session_close'
        assert evt.user == 'deploy'

    def test_timestamp_parsing(self):
        line = "Jun 13 09:14:02 prod-web01 sshd[14213]: Failed password for root from 203.0.113.55 port 51422 ssh2"
        evt = self.parser.parse_line(line)
        assert evt.timestamp == datetime(2026, 6, 13, 9, 14, 2)

    def test_empty_line(self):
        assert self.parser.parse_line("") is None
        assert self.parser.parse_line("   \n") is None

    def test_unparseable_line(self):
        assert self.parser.parse_line("this is not a valid syslog line") is None

    def test_parse_text_multiple_lines(self):
        text = (
            "Jun 13 09:14:02 prod-web01 sshd[14213]: Failed password for root from 203.0.113.55 port 51422 ssh2\n"
            "Jun 13 09:14:03 prod-web01 sshd[14214]: Failed password for root from 203.0.113.55 port 51423 ssh2\n"
        )
        events = self.parser.parse_text(text)
        assert len(events) == 2
        assert all(e.event_type == 'failed_login' for e in events)

    def test_to_dict(self):
        line = "Jun 13 09:14:02 prod-web01 sshd[14213]: Failed password for root from 203.0.113.55 port 51422 ssh2"
        evt = self.parser.parse_line(line)
        d = evt.to_dict()
        assert d['user'] == 'root'
        assert d['event_type'] == 'failed_login'


# ─── Feature Builder Tests ─────────────────────────────────

class TestFeatureBuilder:
    def setup_method(self):
        self.parser = AuthLogParser(default_year=2026)
        self.builder = FeatureBuilder(window_minutes=10)

    def test_build_empty_events(self):
        df = self.builder.build([])
        assert df.empty

    def test_build_groups_by_ip_and_window(self):
        text = (
            "Jun 13 09:14:02 prod-web01 sshd[14213]: Failed password for root from 203.0.113.55 port 51422 ssh2\n"
            "Jun 13 09:14:05 prod-web01 sshd[14215]: Failed password for admin from 203.0.113.55 port 51424 ssh2\n"
        )
        events = self.parser.parse_text(text)
        df = self.builder.build(events)
        assert len(df) == 1  # Same IP, same window
        assert df.iloc[0]['failed_login_count'] == 2

    def test_distinct_usernames_tried(self):
        text = (
            "Jun 13 09:14:02 prod-web01 sshd[1]: Failed password for root from 1.2.3.4 port 1 ssh2\n"
            "Jun 13 09:14:05 prod-web01 sshd[2]: Failed password for admin from 1.2.3.4 port 2 ssh2\n"
            "Jun 13 09:14:07 prod-web01 sshd[3]: Failed password for guest from 1.2.3.4 port 3 ssh2\n"
        )
        events = self.parser.parse_text(text)
        df = self.builder.build(events)
        assert df.iloc[0]['distinct_usernames_tried'] == 3

    def test_different_windows_separated(self):
        text = (
            "Jun 13 09:01:00 prod-web01 sshd[1]: Failed password for root from 1.2.3.4 port 1 ssh2\n"
            "Jun 13 09:25:00 prod-web01 sshd[2]: Failed password for root from 1.2.3.4 port 2 ssh2\n"
        )
        events = self.parser.parse_text(text)
        df = self.builder.build(events)
        assert len(df) == 2  # 10-min windows: 09:00 and 09:20

    def test_feature_matrix_shape(self):
        text = "Jun 13 09:14:02 prod-web01 sshd[1]: Failed password for root from 1.2.3.4 port 1 ssh2\n"
        events = self.parser.parse_text(text)
        df = self.builder.build(events)
        matrix = self.builder.feature_matrix(df)
        assert matrix.shape == (1, len(self.builder.FEATURE_NAMES))


# ─── Anomaly Detector Tests ────────────────────────────────

class TestAnomalyDetector:
    def setup_method(self):
        self.parser = AuthLogParser(default_year=2026)
        self.builder = FeatureBuilder(window_minutes=10)
        self.detector = AnomalyDetector(contamination=0.2, random_state=42)

    def _build_mixed_dataset(self):
        """Build a dataset with normal + clearly anomalous behavior."""
        lines = []
        # Normal logins, several different IPs, low volume
        for i in range(8):
            lines.append(f"Jun 13 0{i % 9}:0{i}:00 host sshd[{i}]: Accepted password for user{i} from 10.0.0.{i+1} port {1000+i} ssh2")
        # One clearly anomalous burst: many failed logins, many usernames, from 1 IP
        for i in range(15):
            lines.append(f"Jun 13 09:14:{i:02d} host sshd[{100+i}]: Failed password for invalid user attacker{i} from 203.0.113.55 port {2000+i} ssh2")
        text = "\n".join(lines)
        events = self.parser.parse_text(text)
        return self.builder.build(events)

    def test_fit_raises_on_empty(self):
        with pytest.raises(ValueError):
            self.detector.fit(pd.DataFrame())

    def test_score_raises_if_not_fitted(self):
        df = self._build_mixed_dataset()
        with pytest.raises(RuntimeError):
            self.detector.score(df)

    def test_fit_predict_flags_anomaly(self):
        df = self._build_mixed_dataset()
        scored = self.detector.fit_predict(df)
        assert 'is_anomaly' in scored.columns
        assert 'risk_score' in scored.columns
        # The attacker IP should be flagged as the top anomaly
        top_row = scored.iloc[0]
        assert top_row['source_ip'] == '203.0.113.55'
        assert top_row['is_anomaly'] == True

    def test_risk_score_range(self):
        df = self._build_mixed_dataset()
        scored = self.detector.fit_predict(df)
        assert scored['risk_score'].min() >= 0
        assert scored['risk_score'].max() <= 100

    def test_explain_features_returns_nonzero(self):
        df = self._build_mixed_dataset()
        scored = self.detector.fit_predict(df)
        top_row = scored.iloc[0]
        explanations = self.detector.explain_features(top_row)
        assert len(explanations) > 0
        assert all(val > 0 for _, val, _ in explanations)

    def test_sorted_descending_by_risk(self):
        df = self._build_mixed_dataset()
        scored = self.detector.fit_predict(df)
        risk_values = scored['risk_score'].tolist()
        assert risk_values == sorted(risk_values, reverse=True)


# ─── LLM Narrator Tests (offline/template mode) ────────────

class TestLLMNarrator:
    def setup_method(self):
        # Force offline mode regardless of environment
        self.narrator = LLMNarrator(api_key=None)

    def test_llm_disabled_without_key(self):
        assert self.narrator.llm_enabled == False

    def test_template_narration_brute_force(self):
        row = pd.Series({
            'source_ip': '203.0.113.55',
            'risk_score': 95.0,
            'failed_login_count': 8,
            'invalid_user_count': 0,
            'distinct_usernames_tried': 1,
            'sudo_command_count': 0,
            'distinct_target_users': 0,
            'failure_to_success_ratio': 8.0,
            'events_per_minute': 5.0,
            'night_time_activity': 0.0,
        })
        result = self.narrator.narrate_finding(row, [])
        assert "Brute-force" in result
        assert "203.0.113.55" in result

    def test_template_narration_enumeration(self):
        row = pd.Series({
            'source_ip': '45.33.22.11',
            'risk_score': 88.0,
            'failed_login_count': 2,
            'invalid_user_count': 5,
            'distinct_usernames_tried': 5,
            'sudo_command_count': 0,
            'distinct_target_users': 0,
            'failure_to_success_ratio': 2.0,
            'events_per_minute': 3.0,
            'night_time_activity': 0.0,
        })
        result = self.narrator.narrate_finding(row, [])
        assert "enumeration" in result.lower()

    def test_template_narration_privilege_escalation(self):
        row = pd.Series({
            'source_ip': 'local:support',
            'risk_score': 93.0,
            'failed_login_count': 0,
            'invalid_user_count': 0,
            'distinct_usernames_tried': 1,
            'sudo_command_count': 4,
            'distinct_target_users': 2,
            'failure_to_success_ratio': 0.0,
            'events_per_minute': 2.0,
            'night_time_activity': 1.0,
        })
        result = self.narrator.narrate_finding(row, [])
        assert "privilege escalation" in result.lower()

    def test_narrate_report_no_anomalies(self):
        df = pd.DataFrame({'is_anomaly': [False, False]})
        result = self.narrator.narrate_report(df, detector=None)
        assert "No anomalous" in result

    def test_response_format_contains_required_fields(self):
        row = pd.Series({
            'source_ip': '1.2.3.4', 'risk_score': 50.0, 'failed_login_count': 3,
            'invalid_user_count': 0, 'distinct_usernames_tried': 1, 'sudo_command_count': 0,
            'distinct_target_users': 0, 'failure_to_success_ratio': 1.0,
            'events_per_minute': 1.0, 'night_time_activity': 0.0,
        })
        result = self.narrator.narrate_finding(row, [])
        assert "SUMMARY:" in result
        assert "LIKELY ATTACK PATTERN:" in result
        assert "RECOMMENDED ACTION:" in result


# ─── Integration Test ──────────────────────────────────────

class TestEndToEndPipeline:
    def test_full_pipeline_on_sample_log(self):
        """Smoke test: full pipeline runs without error on the bundled sample log."""
        sample_path = os.path.join(os.path.dirname(__file__), '..', 'sample_logs', 'sample_auth.log')
        if not os.path.exists(sample_path):
            pytest.skip("sample_auth.log not found")

        parser = AuthLogParser(default_year=2026)
        events = parser.parse_file(sample_path)
        assert len(events) > 0

        builder = FeatureBuilder(window_minutes=10)
        feature_df = builder.build(events)
        assert not feature_df.empty

        detector = AnomalyDetector(contamination=0.2)
        scored = detector.fit_predict(feature_df)
        assert scored['is_anomaly'].sum() > 0

        narrator = LLMNarrator(api_key=None)
        report = narrator.narrate_report(scored, detector, top_n=5)
        assert len(report) > 0
