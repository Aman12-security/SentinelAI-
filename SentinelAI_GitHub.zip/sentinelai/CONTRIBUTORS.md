# 👥 Contributors

## Author & Maintainer

**Aman** — Cybersecurity student (B.Tech CSE, Chandigarh University), EC-Council certified (CCT, NDE; CEH in progress)

Project conceived and built as a cybersecurity + AI/ML portfolio piece, demonstrating:
- Unsupervised machine learning applied to security log analysis
- LLM integration for security operations narration
- Production-style Python CLI tool design and testing

---

## Want to contribute?

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines. All contributors will be listed here.
